<?php

namespace Database\Seeders;

use App\Models\{
    School, Grade, SchoolClass, Subject, User,
    Student, Attendance, Assessment, Message
};
use Illuminate\Database\Seeder;
use Carbon\Carbon;
use Database\Seeders\Support\Helpers;

class DemoSeeder extends Seeder
{
    public function run(): void
    {

    }
}
